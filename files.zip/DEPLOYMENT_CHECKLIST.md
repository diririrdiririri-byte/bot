# 🎯 DEPLOYMENT KONTROL LİSTESİ

Botunuzu deploy etmeden önce bu listeyi kontrol edin:

## ✅ Yapılması Gerekenler

### 1. Bot Bilgilerini Kontrol Edin
- [ ] `bot.py` dosyasında `BOT_OWNER_ID` doğru mu?
- [ ] `ROOM_ID` doğru mu?
- [ ] `BOT_TOKEN` doğru mu?

### 2. GitHub Hazırlığı
- [ ] GitHub hesabınız var mı?
- [ ] Yeni bir repository oluşturdunuz mu?
- [ ] Repository PUBLIC olarak ayarlandı mı?

### 3. Dosyaları GitHub'a Yükleyin

Terminal/CMD'de şu komutları çalıştırın:

```bash
git init
git add .
git commit -m "Highrise bot deploy"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADINIZ/REPO_ADINIZ.git
git push -u origin main
```

**NOT**: `KULLANICI_ADINIZ` ve `REPO_ADINIZ` kısımlarını kendi bilgilerinizle değiştirin!

### 4. Render.com Kurulumu
- [ ] [render.com](https://render.com) hesabı oluşturdunuz mu?
- [ ] GitHub hesabınızı bağladınız mı?
- [ ] "New +" > "Web Service" seçtiniz mi?
- [ ] GitHub repository'nizi seçtiniz mi?

### 5. Render Ayarları

```
Name: highrise-bot
Environment: Python 3
Build Command: pip install -r requirements.txt
Start Command: python bot.py
Plan: Free
```

- [ ] Bu ayarları yaptınız mı?
- [ ] "Create Web Service" butonuna tıkladınız mı?

### 6. Deploy Tamamlandı!
- [ ] Render dashboard'da "Live" yazısını görüyor musunuz?
- [ ] Logs'da hata var mı?
- [ ] Bot Highrise'da aktif mi?

## 🔧 Sorun Giderme

### Bot başlamıyor?
1. Render Logs'u kontrol edin
2. Token ve ID'lerin doğru olduğunu kontrol edin
3. Highrise bot token'ının aktif olduğunu kontrol edin

### Bot 15 dakika sonra uyuyor mu?
1. [UptimeRobot](https://uptimerobot.com) kullanın
2. Render URL'inizi ekleyin
3. 5 dakikada bir ping atmasını ayarlayın

### Veriler kayboluyor mu?
- Render free tier her restart'ta dosyaları siler
- Kalıcı veri için database gerekir (MongoDB, PostgreSQL vb.)

## 🎉 BAŞARILAR!

Bot artık 7/24 çalışıyor! 🚀

Sorun yaşarsanız Render'ın loglarını kontrol edin.
