# ⚡ HIZLI BAŞLANGIÇ REHBERİ

## 🎯 5 Dakikada Deployment

### Adım 1️⃣: GitHub'a Yükle (2 dakika)

1. [github.com](https://github.com) → "New repository"
2. İsim: `highrise-bot` (public yapın)
3. Bilgisayarınızda terminal/CMD açın:

```bash
cd [dosyaların olduğu klasör]
git init
git add .
git commit -m "Bot ready"
git branch -M main
git remote add origin https://github.com/[kullanici_adin]/highrise-bot.git
git push -u origin main
```

### Adım 2️⃣: Render'a Deploy Et (2 dakika)

1. [render.com](https://render.com) → Sign up (GitHub ile)
2. "New +" → "Web Service"
3. Repository'nizi seçin
4. Ayarlar:
   ```
   Name: highrise-bot
   Build: pip install -r requirements.txt
   Start: python bot.py
   Plan: Free
   ```
5. "Create Web Service" → TAMAM! ✅

### Adım 3️⃣: Sürekli Aktif Tut (1 dakika)

1. [uptimerobot.com](https://uptimerobot.com) → Sign up
2. "Add Monitor"
3. Render URL'nizi yapıştırın
4. Interval: 5 dakika
5. Kaydet → TAMAM! ✅

## 🎉 BİTTİ!

Botunuz şimdi 7/24 çalışıyor!

## 📋 Dosya Açıklamaları

| Dosya | Ne İşe Yarar? |
|-------|---------------|
| `bot.py` | Ana bot kodu |
| `requirements.txt` | Python paketleri |
| `Procfile` | Render başlangıç komutu |
| `render.yaml` | Render otomatik ayarlar |
| `keep_alive.py` | Uyumayı önler |
| `.gitignore` | Git'e dahil edilmeyecekler |

## ❓ Sorun mu Var?

### Bot başlamıyor
→ Render Logs'u kontrol et
→ Token ve ID'leri kontrol et

### Bot uyuyor
→ UptimeRobot kurulumunu kontrol et
→ Ping intervali 5 dakika olmalı

### Veriler kayboluyor
→ Normal (Render free tier özelliği)
→ Kalıcı veri için MongoDB ekleyin

## 🚀 İleri Seviye

**MongoDB Eklemek için:**
1. [mongodb.com/cloud/atlas](https://mongodb.com/cloud/atlas) → Free cluster
2. Connection string alın
3. `pymongo` ekleyin requirements.txt'e
4. Bot'a database kodu ekleyin

**Custom Domain için:**
1. Render Paid Plan ($7/ay)
2. Settings → Custom Domain
3. DNS ayarlarını yapın

---

**Kolay gelsin! 🎮**
