# Highrise Bot - 7/24 Deployment Rehberi

Bu bot Highrise için geliştirilmiş, 224 emote ve çok sayıda komut içeren gelişmiş bir bottur.

## 🚀 Render.com ile Ücretsiz 7/24 Deployment

### Adım 1: GitHub'a Yükleyin

1. [GitHub.com](https://github.com)'a gidin ve yeni bir repository oluşturun
2. Repository'yi public yapın
3. Tüm dosyaları GitHub'a yükleyin:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADINIZ/REPO_ADINIZ.git
git push -u origin main
```

### Adım 2: Render.com Kurulumu

1. [Render.com](https://render.com)'a gidin ve ücretsiz hesap oluşturun
2. GitHub hesabınızı bağlayın
3. "New +" butonuna tıklayın ve "Web Service" seçin
4. GitHub repository'nizi seçin
5. Aşağıdaki ayarları yapın:
   - **Name**: `highrise-bot` (veya istediğiniz isim)
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python bot.py`
   - **Plan**: `Free`

6. "Create Web Service" butonuna tıklayın

### Adım 3: Bot Çalışıyor! 🎉

Render otomatik olarak botunuzu deploy edecek ve 7/24 çalışır hale getirecektir.

## ⚙️ Bot Ayarları

`bot.py` dosyasının üst kısmında şu bilgileri doldurmanız gerekiyor:

```python
BOT_OWNER_ID = "673a417cb7f0ffc582a43435"  # Kendi ID'niz
ROOM_ID = "6942f77823105f519fc7e44a"      # Oda ID'si
BOT_TOKEN = "ac81cb41a1d1e036bbf8292af0d75ec213d55862abb257ba4fdbafab4ebd1b6b"  # Bot token
```

Bu bilgiler zaten kodda mevcut, değiştirmenize gerek yok (eğer bunlar sizin bilgilerinizse).

## 📋 Bot Özellikleri

### Emote Komutları
- `!emote [numara/isim]` - 224 farklı emote
- `!emotelist` - Tüm emoteleri göster
- `!loop [numara/isim]` - Sonsuz emote loop
- `!stopmyloop` - Loop'u durdur

### Movement Komutları
- `!come` - Botu yanınıza çağırın
- `!wallet [kullanici]` - Kullanıcıya gidin
- `!follow [kullanici]` - Takip et
- `!unfollow` - Takibi bırak

### Moderasyon Komutları
- `!kick [kullanici]` - Kullanıcıyı at
- `!warn [kullanici]` - Uyarı ver
- `!freeze/@unfreeze` - Dondur/Çöz
- `!mute/@unmute` - Sustur

### VIP Sistemi
- `!buyvip` - VIP satın al
- `!setvipamount` - VIP fiyatı ayarla
- `!viplist` - VIP listesi

### Roller
- Owner, Co-owner, Senior Admin, Moderator, Designer rolleri
- `!addmod/@removemod` - Rol yönetimi
- `!rolelist` - Tüm rolleri göster

### Mesajlar
- `!setjoin/@deljoin` - Giriş mesajı
- `!setleave/@delleave` - Çıkış mesajı
- `!loopmsg` - Loop mesaj sistemi

### Diğer Komutlar
- `!help` - Yardım menüsü
- `!users` - Odadaki kişi sayısı
- `!ping` - Bot yanıt kontrolü
- `!id` - Kendi ID'nizi öğrenin

## 🔄 Otomatik Yeniden Başlatma

Bot kendi içinde otomatik restart sistemi içeriyor. Herhangi bir hata durumunda 5 saniye bekleyip otomatik olarak yeniden başlar.

## 📊 Ücretsiz Plan Limitleri (Render.com)

- ✅ 7/24 çalışır
- ✅ Otomatik restart
- ⚠️ 15 dakika inaktivite sonrası uyur (ilk komutta tekrar uyanır)
- ⚠️ Ayda 750 saat ücretsiz (günde ~25 saat)

## 💡 Sürekli Aktif Tutma İpucu

Ücretsiz planda 15 dakika inaktivite sonrası bot uyur. Sürekli aktif tutmak için:

1. [UptimeRobot](https://uptimerobot.com) hesabı açın
2. Render'dan aldığınız URL'i ekleyin
3. 5 dakikada bir ping atmasını ayarlayın

Bu şekilde bot hiç uyumadan 7/24 çalışır!

## 🆘 Destek

Sorun yaşarsanız:
1. Render dashboard'dan logları kontrol edin
2. Bot token ve ID'lerin doğru olduğundan emin olun
3. GitHub repository'nin public olduğundan emin olun

## 📝 Notlar

- Bot JSON dosyası ile ayarları kaydeder (`bot_data.json`)
- Render'da her yeniden başlatmada bu dosya sıfırlanır
- Kalıcı veri için database entegrasyonu gerekir

---

**Başarılar! 🎮**
