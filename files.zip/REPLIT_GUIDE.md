# 🔄 Alternatif: Replit ile Deployment

Render.com yerine Replit kullanmak isterseniz:

## Avantajları
- ✅ Daha kolay kurulum
- ✅ Kod editörü dahili
- ✅ Otomatik requirements kurulumu
- ✅ Ücretsiz plan mevcut

## Dezavantajları
- ⚠️ Ücretsiz planda sınırlı uptime
- ⚠️ İnaktivite sonrası uyur
- ⚠️ Daha yavaş başlama süresi

## Kurulum Adımları

### 1. Replit'e Git
[replit.com](https://replit.com) adresine gidin ve hesap oluşturun

### 2. Yeni Repl Oluştur
- "Create Repl" butonuna tıklayın
- Template: "Python"
- Name: "highrise-bot"

### 3. Dosyaları Yükle
- `bot.py` dosyasını yükleyin (emotes.py olarak)
- `requirements.txt` dosyasını yükleyin
- `keep_alive.py` dosyasını yükleyin

### 4. Main Dosyasını Ayarla
main.py dosyasına şunu yazın:
```python
import bot
```

### 5. Secrets Ekle (Güvenlik İçin - Opsiyonel)
Replit'in "Secrets" özelliğini kullanarak hassas bilgileri gizleyin:

1. Sol panelden "Secrets" seçeneğine tıklayın
2. Şu bilgileri ekleyin:
   - Key: `BOT_OWNER_ID`, Value: `673a417cb7f0ffc582a43435`
   - Key: `ROOM_ID`, Value: `6942f77823105f519fc7e44a`
   - Key: `BOT_TOKEN`, Value: `ac81cb41a1d1e036bbf8292af0d75ec213d55862abb257ba4fdbafab4ebd1b6b`

3. bot.py'de şu şekilde kullanın:
```python
import os

BOT_OWNER_ID = os.environ.get('BOT_OWNER_ID', 'varsayilan_id')
ROOM_ID = os.environ.get('ROOM_ID', 'varsayilan_room')
BOT_TOKEN = os.environ.get('BOT_TOKEN', 'varsayilan_token')
```

### 6. Run Butonuna Tıklayın
- Replit otomatik olarak requirements.txt'i kuracak
- Bot çalışmaya başlayacak

### 7. Her Zaman Aktif Tutma (UptimeRobot)

1. Replit'ten URL'nizi alın (üstte görünür)
2. [UptimeRobot](https://uptimerobot.com) hesabı açın
3. "Add New Monitor" tıklayın
4. URL'nizi ekleyin
5. Monitoring interval: 5 dakika

## 💰 Ücretli Seçenekler

### Replit Hacker Plan ($7/ay)
- ✅ 7/24 uptime
- ✅ Daha fazla RAM ve CPU
- ✅ Hızlı başlama
- ✅ Private repl'ler

### Render Paid Plan ($7/ay)
- ✅ Sınırsız uptime
- ✅ Otomatik SSL
- ✅ Custom domain
- ✅ Daha fazla kaynak

## 🎯 Hangisi Sizin İçin?

**Render.com (ÖNERİLEN)**
- Üretim ortamı için ideal
- Daha stabil
- GitHub entegrasyonu
- Profesyonel deployment

**Replit**
- Test için harika
- Hızlı prototipleme
- Kod düzenleme dahili
- Öğrenme için ideal

## 🔐 Güvenlik Notu

Bot token ve ID gibi hassas bilgileri:
- GitHub'da asla public repository'de paylaşmayın
- Environment variables kullanın
- .env dosyası kullanın (ve .gitignore'a ekleyin)

---

**İyi şanslar! 🚀**
