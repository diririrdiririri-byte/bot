# 📸 GÖRSEL ADIM ADIM REHBERİ

## 🎯 Botunuzu Deploy Edin - Resimli Anlatım

---

## BÖLÜM 1: HAZIRLIK

### ✅ İhtiyaçlar
- [ ] Bot kodunuz hazır (bot.py)
- [ ] GitHub hesabı
- [ ] Render.com hesabı (ücretsiz)
- [ ] 10 dakika zamanınız

---

## BÖLÜM 2: GITHUB'A YÜKLEME

### Adım 1: GitHub Repository Oluştur

1. https://github.com adresine gidin
2. Sağ üstte "+" işaretine tıklayın
3. "New repository" seçin

**Ayarlar:**
```
Repository name: highrise-bot
Description: My Highrise Bot
⚪ Public (ÖNEMLİ!)
☑️ Add a README file
```

4. "Create repository" butonuna tıklayın

### Adım 2: Dosyaları Yükle

**Yöntem A - Web Arayüzünden (Kolay):**
1. Repository sayfasında "Add file" → "Upload files"
2. Tüm dosyaları sürükle bırak:
   - bot.py
   - requirements.txt
   - Procfile
   - render.yaml
   - keep_alive.py
   - README.md
3. "Commit changes" tıklayın

**Yöntem B - Terminal/CMD (İleri Seviye):**
```bash
# Dosyaların olduğu klasöre gidin
cd C:\Users\[kullanici]\Desktop\highrise-bot

# Git başlat
git init

# Tüm dosyaları ekle
git add .

# Commit oluştur
git commit -m "Initial bot deployment"

# Ana branch oluştur
git branch -M main

# GitHub repository'nizi bağlayın
git remote add origin https://github.com/[kullanici_adin]/highrise-bot.git

# Push yapın
git push -u origin main
```

---

## BÖLÜM 3: RENDER.COM DEPLOYMENT

### Adım 1: Render Hesabı Oluştur

1. https://render.com adresine gidin
2. "Get Started" butonuna tıklayın
3. "Sign up with GitHub" seçin
4. GitHub'ı yetkilendirin

### Adım 2: Web Service Oluştur

1. Dashboard'da "New +" butonuna tıklayın
2. "Web Service" seçin
3. GitHub hesabınızı bağlayın (ilk kez ise)
4. Repository'nizi seçin: `highrise-bot`

### Adım 3: Ayarları Yapın

```
════════════════════════════════════════
📝 Service Detayları
════════════════════════════════════════

Name: highrise-bot
Region: Oregon (US West) veya size en yakın
Branch: main

════════════════════════════════════════
⚙️ Build & Deploy
════════════════════════════════════════

Root Directory: [boş bırakın]
Environment: Python 3
Build Command: pip install -r requirements.txt
Start Command: python bot.py

════════════════════════════════════════
💰 Plan
════════════════════════════════════════

Instance Type: Free
   - 0.1 CPU
   - 512 MB RAM
   - Uyuyor modu var (15 dakika sonra)
   - Ayda 750 saat ücretsiz
```

4. "Create Web Service" butonuna tıklayın

### Adım 4: Deploy Süreci

**Şimdi ne oluyor?**

```
⏳ Building...
   └─ Downloading code from GitHub
   └─ Installing Python 3.11
   └─ Installing dependencies (requirements.txt)
      └─ highrise-bot-sdk
      └─ aiohttp
   
⏳ Starting...
   └─ Running: python bot.py
   
✅ Live!
   └─ Bot çalışıyor!
```

**Bu süreç 2-5 dakika sürer.**

### Adım 5: Kontrol Edin

1. Render dashboard'da "Logs" sekmesine tıklayın
2. Görmek istediğiniz:
   ```
   Health check server started on port 8080
   Bot connecting...
   Bot connected successfully!
   ```

3. **ÖNEMLİ:** Üstte yeşil "Live" yazısını görmelisiniz

---

## BÖLÜM 4: SÜREKLI AKTİF TUTMA

### UptimeRobot Kurulumu

**Neden gerekli?**
- Render free tier 15 dakika inaktivite sonrası uyur
- UptimeRobot her 5 dakikada ping atar
- Bot hiç uyumaz! 🎉

**Kurulum:**

1. https://uptimerobot.com adresine gidin
2. "Register for FREE" → Hesap oluşturun
3. Email'inizi doğrulayın

4. Dashboard'da "Add New Monitor" tıklayın

```
════════════════════════════════════════
🔍 Monitor Ayarları
════════════════════════════════════════

Monitor Type: HTTPS
Friendly Name: Highrise Bot
URL (or IP): [Render'dan aldığınız URL]
   Örnek: https://highrise-bot-xxxx.onrender.com

Monitoring Interval: 5 minutes

Alert Contacts: [Email'iniz - otomatik gelir]
```

5. "Create Monitor" tıklayın

**Tebrikler! Bot artık 7/24 çalışıyor! 🎊**

---

## BÖLÜM 5: TEST VE KONTROL

### Botun Çalıştığını Nasıl Anlarım?

1. **Render'da kontrol:**
   - Dashboard → Logs
   - "Live" yazısı görünüyor olmalı
   - Son log'lar: "Bot connected" yazmalı

2. **Highrise'da kontrol:**
   - Odaya girin
   - Bot'u görebiliyor musunuz?
   - `!ping` yazın → "Pong!" cevabı almalısınız

3. **UptimeRobot'ta kontrol:**
   - Dashboard → Monitors
   - Status: "Up" (yeşil) olmalı
   - Uptime: %99+ olmalı

### Test Komutları

```
!ping          → Bot cevap verir mi?
!emote 1       → Emote çalışıyor mu?
!help          → Komutlar yüklenmiş mi?
!users         → Oda bilgisi alıyor mu?
```

---

## 🔧 SORUN GİDERME

### Problem: Bot deploy edilmiyor

**Çözüm:**
1. Render Logs'u kontrol edin
2. Hata mesajlarını okuyun
3. GitHub'daki dosyaları kontrol edin:
   - requirements.txt var mı?
   - bot.py adı doğru mu?

### Problem: Bot başlıyor ama hemen duruyor

**Çözüm:**
```python
# bot.py içinde şunları kontrol edin:
BOT_OWNER_ID = "DOĞRU_ID"     # ✅ Doğru
BOT_OWNER_ID = ""              # ❌ Yanlış

ROOM_ID = "DOĞRU_ROOM_ID"      # ✅ Doğru
ROOM_ID = None                 # ❌ Yanlış

BOT_TOKEN = "DOĞRU_TOKEN"      # ✅ Doğru
BOT_TOKEN = ""                 # ❌ Yanlış
```

### Problem: Bot 15 dakika sonra uyuyor

**Çözüm:**
- UptimeRobot kurulumunu kontrol edin
- Monitor'ün "Up" durumunda olduğundan emin olun
- Interval'in 5 dakika olduğunu kontrol edin

### Problem: Veriler kayboluyor

**Çözüm:**
- Bu normaldir (Render free tier özelliği)
- Her restart'ta `bot_data.json` sıfırlanır
- Kalıcı veri için MongoDB kullanın

---

## 📊 LOGS NASIL OKUNUR

### Normal Logs (Her Şey Yolunda):
```
2024-01-28 12:00:00 | Health check server started on port 8080
2024-01-28 12:00:01 | Starting bot...
2024-01-28 12:00:02 | Connecting to Highrise...
2024-01-28 12:00:05 | ✅ Bot connected successfully!
2024-01-28 12:00:05 | Room ID: 6942f77823105f519fc7e44a
2024-01-28 12:00:05 | Bot ready and running!
```

### Hatalı Logs (Sorun Var):
```
2024-01-28 12:00:00 | Health check server started on port 8080
2024-01-28 12:00:01 | Starting bot...
2024-01-28 12:00:02 | ❌ Error: Invalid token
2024-01-28 12:00:02 | Bot hatasi: Authentication failed
2024-01-28 12:00:07 | 5 saniye sonra yeniden baslatiliyor...
```

**Hata türleri:**
- `Invalid token` → Token yanlış
- `Room not found` → Room ID yanlış
- `Permission denied` → Bot yetkisi yok
- `Module not found` → requirements.txt eksik

---

## 🎓 İLERİ SEVİYE İPUÇLARI

### 1. Environment Variables Kullanın

Hassas bilgileri kod içinde yazmak yerine:

1. Render Dashboard → Environment sekmesi
2. "Add Environment Variable" tıklayın
3. Ekleyin:
   ```
   BOT_OWNER_ID = 673a417cb7f0ffc582a43435
   ROOM_ID = 6942f77823105f519fc7e44a
   BOT_TOKEN = ac81cb41a...
   ```

4. bot.py'de kullanın:
   ```python
   import os
   BOT_OWNER_ID = os.environ.get('BOT_OWNER_ID')
   ```

### 2. Otomatik Deploy

GitHub'a her push'ta otomatik deploy:

1. Render → Settings
2. "Auto-Deploy" → Yes

Artık GitHub'a kod attığınızda bot otomatik güncellenir!

### 3. Custom Domain

Kendi domain'iniz var mı?

1. Render Paid Plan ($7/ay)
2. Settings → Custom Domain
3. Domain'inizi ekleyin
4. DNS ayarlarını yapın

Örnek: `bot.sizindomain.com`

### 4. Veritabanı Ekleyin

MongoDB ile kalıcı veri:

1. https://mongodb.com/cloud/atlas → Free cluster
2. Connection string alın
3. requirements.txt'e ekleyin:
   ```
   pymongo==4.6.1
   ```
4. bot.py'de kullanın:
   ```python
   from pymongo import MongoClient
   client = MongoClient(MONGO_URL)
   db = client['highrise_bot']
   ```

---

## 📞 DESTEK

### Sorun mu yaşıyorsunuz?

1. **Render Logs'u kontrol edin**
   - Hatayı gösterir
   - Çözüm için Google'da arayın

2. **GitHub Issues**
   - Repository'nizde Issue açın
   - Sorununuzu detaylı anlatın

3. **Discord/Forum**
   - Highrise developer topluluğuna sorun
   - Logs'u paylaşın

### Yararlı Linkler

- Render Docs: https://render.com/docs
- Highrise SDK: https://github.com/pocketsizesun/highrise-bot-sdk
- Python Docs: https://docs.python.org/3/

---

## ✅ SON KONTROL LİSTESİ

Deploy öncesi:
- [ ] Bot.py'de ID'ler doğru
- [ ] requirements.txt var
- [ ] Procfile var
- [ ] GitHub repository public

Deploy sırası:
- [ ] GitHub'a yüklendi
- [ ] Render'da service oluşturuldu
- [ ] Build başarılı
- [ ] "Live" durumunda

Deploy sonrası:
- [ ] Bot Highrise'da görünüyor
- [ ] Komutlar çalışıyor
- [ ] UptimeRobot kuruldu
- [ ] Monitor "Up" durumunda

---

## 🎉 BAŞARILAR!

Botunuz artık 7/24 çalışıyor ve dünya çapında erişilebilir!

**Ne yapabilirsiniz?**
- ✅ Komutları test edin
- ✅ Yeni özellikler ekleyin
- ✅ Arkadaşlarınızla paylaşın
- ✅ Geri bildirim toplayın

**Sonraki adımlar:**
1. MongoDB ekleyin (kalıcı veri)
2. Daha fazla komut ekleyin
3. Web dashboard oluşturun
4. API entegrasyonları yapın

---

**Kolay gelsin! 🚀**

---

## 📝 NOTLAR

- Free tier: Ayda 750 saat (günde ~25 saat)
- Paid tier: $7/ay ile sınırsız
- UptimeRobot: Ücretsiz 50 monitor
- MongoDB: Ücretsiz 512MB

Bu kılavuz Ocak 2024 itibariyle günceldir.
